#include "SceneLoader.h"
#include <string>

// Constructor
SceneLoader::SceneLoader() {

	sceneDescriptor.push_back("");
	scenesMap["Introduction"] = sceneDescriptor;

}

// Destructor 
SceneLoader::~SceneLoader() {

}

void SceneLoader::SetDescription(std::string lineDesc) {

	if (sceneDescriptor[0] == "") {

		sceneDescriptor[0] = lineDesc;

	}
	else {

		sceneDescriptor.push_back(lineDesc);

	}

}

void SceneLoader::AddToMap(std::string sceneID) {

	scenesMap[sceneID] = sceneDescriptor;
	sceneDescriptor.clear();

}

void SceneLoader::SetChoices(std::string lineChoiceDesc, std::string lineChoiceID) {

	choicesMap[lineChoiceDesc] = lineChoiceID;

}