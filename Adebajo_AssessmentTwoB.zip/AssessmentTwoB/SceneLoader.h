#ifndef SCENELOADER_H
#define SCENELOADER_H 

// Includes
#include <string>
#include <map>
#include <vector>


class SceneLoader {

public:
	SceneLoader();
	~SceneLoader();

	void PrintDescription();
	void SetDescription(std::string lineDesc);
	void AddToMap(std::string sceneID);
	void SetChoices(std::string lineChoiceDesc, std::string lineChoiceID);

protected:
	std::vector<std::string> sceneDescriptor;
	std::map<std::string, std::vector<std::string>> scenesMap;
	std::map<std::string, std::string> choicesMap;
};

#endif 
