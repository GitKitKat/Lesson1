#ifndef ADVENTUREOBJECT_H
#define ADVENTUREOBJECT_H 

#include <string>

class AdventureObject {

public:
	AdventureObject();
	~AdventureObject();

	void ChangeTime(float timeDecrease);
	std::string GetFile();
	virtual void TellTime() = 0;
	
protected: 
	float time;
	std::string filename;
};

#endif 