#include "AdventureObject.h"

// Constructor
AdventureObject::AdventureObject() {

	time = 0;
	filename = "";

}

// Destructor
AdventureObject::~AdventureObject() {

}

// Returns the name of the file connected to the text adventure.
std::string AdventureObject::GetFile() {

	return filename;

}

// Decreases the remaining time by an inputed amount.
void AdventureObject::ChangeTime(float timeDecrease) {

	time -= timeDecrease;

}